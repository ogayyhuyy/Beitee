import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, decimal, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const gameEnum = pgEnum("game_type", ["Mobile Legends", "Free Fire", "The Spike"]);
export const loginMethodEnum = pgEnum("login_method", ["Moonton", "Google", "Facebook", "VK", "Guest"]);
export const statusEnum = pgEnum("account_status", ["TERSEDIA", "SOLD"]);

export const users = pgTable("users", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  whatsapp: text("whatsapp").notNull(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const gameAccounts = pgTable("game_accounts", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  unitCode: varchar("unit_code", { length: 20 }).notNull().unique(),
  game: text("game").notNull(),
  rank: text("rank").notNull(),
  price: decimal("price", { precision: 15, scale: 2 }).notNull(),
  loginMethod: text("login_method").notNull(),
  description: text("description").notNull().default(""),
  imageUrls: text("image_urls").notNull().default("[]"),
  status: text("status").notNull().default("TERSEDIA"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const testimonials = pgTable("testimonials", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  username: text("username").notNull(),
  game: text("game").notNull(),
  rating: integer("rating").notNull().default(5),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertGameAccountSchema = createInsertSchema(gameAccounts).omit({
  id: true,
  unitCode: true,
  createdAt: true,
});

export const insertTestimonialSchema = createInsertSchema(testimonials).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertGameAccount = z.infer<typeof insertGameAccountSchema>;
export type GameAccount = typeof gameAccounts.$inferSelect;

export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;
export type Testimonial = typeof testimonials.$inferSelect;
