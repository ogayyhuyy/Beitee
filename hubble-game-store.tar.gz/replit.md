# Hubble Game Store

A dark neon-themed game account marketplace for selling Mobile Legends, Free Fire, and The Spike accounts.

## Architecture

- **Frontend**: React + TypeScript + Vite + TailwindCSS + shadcn/ui
- **Backend**: Express.js + TypeScript
- **Database**: PostgreSQL via Drizzle ORM
- **Routing**: wouter (client-side)
- **State/Fetching**: TanStack Query v5
- **Session**: express-session + connect-pg-simple

## Features

- Public account browsing with game/status filters
- User authentication (register/login) with sessions
- Account detail pages with image slider
- WhatsApp purchase integration (wa.me/6281229314973)
- Admin panel for full account CRUD
- Image uploads via multer
- Dark neon gaming theme (electric blue + neon purple)

## Supported Games

- Mobile Legends
- Free Fire
- The Spike

## Login Methods for Accounts

- Moonton, Google, Facebook, VK, Guest

## Admin

- URL: `/admin/login`
- Username: `admin`
- Password: `hubble123`

## Key Files

- `shared/schema.ts` - Database schema (users, gameAccounts, testimonials)
- `server/routes.ts` - All API routes
- `server/storage.ts` - Database storage layer
- `server/index.ts` - Express app with session middleware
- `client/src/App.tsx` - Router and providers
- `client/src/context/AuthContext.tsx` - Authentication context
- `client/src/pages/` - All pages
- `client/src/components/` - Reusable components

## Unit Code System

Account unit codes are auto-generated: HS001, HS002, HS003, etc.

## WhatsApp Integration

Purchase flow redirects to: `https://wa.me/6281229314973?text=...`

## Image Storage

Uploaded images stored in `/uploads/` folder, served at `/api/uploads/`
