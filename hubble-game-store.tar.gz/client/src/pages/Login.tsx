import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Gamepad2, LogIn, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Login() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [usernameOrEmail, setUsernameOrEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);

  const loginMutation = useMutation({
    mutationFn: (data: { usernameOrEmail: string; password: string }) =>
      apiRequest("POST", "/api/auth/login", data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({ title: "Berhasil login!", description: "Selamat datang kembali." });
      navigate("/");
    },
    onError: async (err: any) => {
      const body = err?.body || {};
      toast({
        title: "Login Gagal",
        description: body?.error || "Username/email atau password salah.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameOrEmail || !password) return;
    loginMutation.mutate({ usernameOrEmail, password });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      {/* Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div style={{
          position: "absolute", inset: 0,
          background: "radial-gradient(ellipse at 20% 40%, rgba(0,255,255,0.08) 0%, transparent 50%), radial-gradient(ellipse at 80% 60%, rgba(157,0,255,0.08) 0%, transparent 50%)"
        }} />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-[0_0_20px_rgba(0,255,255,0.4)]">
              <Gamepad2 className="w-7 h-7 text-black" />
            </div>
            <span className="font-display font-black text-3xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              HUBBLE
            </span>
          </Link>
          <p className="text-muted-foreground mt-2">Masuk ke akun Anda</p>
        </div>

        {/* Form Card */}
        <div className="bg-card border border-white/10 rounded-2xl p-8 shadow-2xl">
          <h2 className="text-2xl font-display font-bold text-white mb-6">Login</h2>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor="usernameOrEmail">
                Username atau Email
              </label>
              <input
                id="usernameOrEmail"
                type="text"
                value={usernameOrEmail}
                onChange={e => setUsernameOrEmail(e.target.value)}
                placeholder="username atau email@example.com"
                required
                data-testid="input-username-or-email"
                className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-all"
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor="password">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Masukkan password"
                  required
                  data-testid="input-password"
                  className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 pr-12 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white transition-colors"
                >
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loginMutation.isPending}
              data-testid="button-submit-login"
              className="w-full py-3.5 rounded-xl bg-primary text-black font-display font-bold text-lg hover:bg-white hover:shadow-[0_0_20px_rgba(0,255,255,0.5)] transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loginMutation.isPending ? (
                <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="w-5 h-5" />
                  Masuk
                </>
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-muted-foreground text-sm">
            Belum punya akun?{" "}
            <Link href="/daftar" className="text-primary font-bold hover:underline">
              Daftar sekarang
            </Link>
          </p>
        </div>

        <p className="text-center mt-6 text-muted-foreground text-sm">
          <Link href="/" className="hover:text-primary transition-colors">Kembali ke Home</Link>
        </p>
      </div>
    </div>
  );
}
