import { Navbar } from "@/components/Navbar";
import { useQuery } from "@tanstack/react-query";
import { Star, Quote, Gamepad2 } from "lucide-react";

interface Testimonial {
  id: number;
  username: string;
  game: string;
  rating: number;
  message: string;
  createdAt: string;
}

const defaultTestimonials = [
  {
    id: 1,
    username: "RaiderX99",
    game: "Mobile Legends",
    rating: 5,
    message: "Mantap banget! Akun ML-nya sesuai deskripsi, proses cepet, admin responsif. Langsung jadi Mythical Glory!",
    createdAt: new Date().toISOString(),
  },
  {
    id: 2,
    username: "SniperKing21",
    game: "Free Fire",
    rating: 5,
    message: "Udah beli 3x di sini, selalu puas. Akun FF-nya lengkap skinnya, aman dan terpercaya. Highly recommended!",
    createdAt: new Date().toISOString(),
  },
  {
    id: 3,
    username: "SpikeMaster",
    game: "The Spike",
    rating: 5,
    message: "Pertama kali beli akun game online, awalnya takut kena tipu. Tapi Hubble Store beneran legit! Akun The Spike-nya keren.",
    createdAt: new Date().toISOString(),
  },
  {
    id: 4,
    username: "GalaxyWarrior",
    game: "Mobile Legends",
    rating: 5,
    message: "Admin ramah dan helpful banget. Proses transfer akun cepat, kurang dari 10 menit udah beres. Worth it banget!",
    createdAt: new Date().toISOString(),
  },
  {
    id: 5,
    username: "PhantomShot",
    game: "Free Fire",
    rating: 5,
    message: "Harganya kompetitif banget dibanding tempat lain. Akun FF Grand Master dengan banyak skin rare. Puas banget!",
    createdAt: new Date().toISOString(),
  },
  {
    id: 6,
    username: "NightBladeX",
    game: "Mobile Legends",
    rating: 5,
    message: "Beli akun ML dengan hero banyak dan skin limited. Semuanya sesuai foto. Transaksi via WA lancar. Recommended!",
    createdAt: new Date().toISOString(),
  },
];

export default function Testimonials() {
  const { data } = useQuery<{ testimonials: Testimonial[] }>({
    queryKey: ["/api/testimonials"],
  });

  const testimonials = data?.testimonials?.length ? data.testimonials : defaultTestimonials;

  return (
    <div className="min-h-screen bg-background pt-32 pb-20">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary mb-8">
            <Star className="w-4 h-4 fill-primary" />
            <span className="text-sm font-bold tracking-wider uppercase">Testimoni Pembeli</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-display font-black text-white mb-6">
            Kata Mereka yang <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Sudah Beli</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Ratusan gamer telah mempercayakan kebutuhan akun game mereka kepada Hubble Store.
          </p>

          {/* Rating Summary */}
          <div className="inline-flex items-center gap-4 mt-8 bg-card px-8 py-4 rounded-2xl border border-white/5">
            <div className="text-center">
              <p className="text-4xl font-display font-black text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">5.0</p>
              <div className="flex gap-1 mt-1 justify-center">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                ))}
              </div>
            </div>
            <div className="h-12 w-px bg-white/10" />
            <div className="text-center">
              <p className="text-2xl font-display font-black text-white">500+</p>
              <p className="text-xs text-muted-foreground mt-1">Transaksi Sukses</p>
            </div>
            <div className="h-12 w-px bg-white/10" />
            <div className="text-center">
              <p className="text-2xl font-display font-black text-white">100%</p>
              <p className="text-xs text-muted-foreground mt-1">Kepuasan Pembeli</p>
            </div>
          </div>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.id}
              className="bg-card rounded-2xl border border-white/5 p-6 relative overflow-hidden group hover:border-primary/20 transition-all duration-300"
              data-testid={`card-testimonial-${t.id}`}
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/3 rounded-full blur-3xl pointer-events-none" />

              <Quote className="w-8 h-8 text-primary/30 mb-4" />

              <p className="text-muted-foreground leading-relaxed mb-6 relative z-10">
                "{t.message}"
              </p>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center font-display font-bold text-black text-sm">
                    {t.username.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-bold text-white text-sm">{t.username}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Gamepad2 className="w-3 h-3" /> {t.game}
                    </p>
                  </div>
                </div>

                <div className="flex gap-0.5">
                  {[...Array(5)].map((_, j) => (
                    <Star
                      key={j}
                      className={`w-3.5 h-3.5 ${j < t.rating ? "text-yellow-400 fill-yellow-400" : "text-white/20"}`}
                    />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-4">Gabung dan rasakan sendiri pengalaman berbelanja di Hubble Store!</p>
          <div className="flex justify-center gap-4 flex-wrap">
            <a
              href="/accounts"
              className="px-8 py-4 rounded-xl bg-primary text-black font-bold hover:bg-white hover:shadow-[0_0_30px_rgba(0,255,255,0.6)] transition-all duration-300"
            >
              Mulai Belanja
            </a>
            <a
              href="/cara-beli"
              className="px-8 py-4 rounded-xl bg-card border border-white/10 text-white font-bold hover:border-primary/50 transition-all"
            >
              Cara Beli
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
