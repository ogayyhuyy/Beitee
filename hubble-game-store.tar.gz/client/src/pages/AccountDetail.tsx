import { useParams, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { Navbar } from "@/components/Navbar";
import { useState } from "react";
import { ChevronLeft, ChevronRight, Gamepad2, Shield, LogIn, ExternalLink, ArrowLeft, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GameAccount {
  id: number;
  unitCode: string;
  game: string;
  rank: string;
  price: number;
  loginMethod: string;
  description: string;
  imageUrls: string[];
  status: string;
  createdAt: string;
}

export default function AccountDetail() {
  const params = useParams();
  const id = Number(params.id);
  const { data: accountData, isLoading, isError } = useQuery<{ account: GameAccount }>({
    queryKey: [`/api/accounts/${id}`],
    enabled: !!id,
  });

  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  const [currentImg, setCurrentImg] = useState(0);

  const account = accountData?.account;
  const isSold = account?.status === "SOLD";
  const images = account?.imageUrls && account.imageUrls.length > 0 ? account.imageUrls : null;

  const handleNext = () => {
    if (images) setCurrentImg((prev) => (prev + 1) % images.length);
  };

  const handlePrev = () => {
    if (images) setCurrentImg((prev) => (prev - 1 + images.length) % images.length);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const handleBuy = () => {
    if (isSold) return;

    if (!isAuthenticated) {
      toast({
        title: "Akses Ditolak",
        description: "Silakan login atau daftar terlebih dahulu untuk membeli akun.",
        variant: "destructive",
      });
      return;
    }

    if (account) {
      const message = `Halo admin Hubble Store!\nSaya ingin membeli akun berikut:\n\nKode Unit: ${account.unitCode}\nGame: ${account.game}\nRank: ${account.rank}\nHarga: ${formatPrice(account.price)}\n\nMohon konfirmasinya, terima kasih!`;
      const url = `https://wa.me/6281229314973?text=${encodeURIComponent(message)}`;
      window.open(url, "_blank");
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="pt-32 pb-20 max-w-5xl mx-auto px-4">
          <div className="h-[400px] bg-card animate-pulse rounded-3xl mb-8 border border-white/5" />
          <div className="h-64 bg-card animate-pulse rounded-3xl border border-white/5" />
        </div>
      </div>
    );
  }

  if (isError || !account) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
        <Navbar />
        <div className="text-center mt-32">
          <Gamepad2 className="w-16 h-16 text-primary/30 mx-auto mb-6" />
          <h1 className="text-3xl font-display font-bold text-white mb-4">Akun Tidak Ditemukan</h1>
          <Link href="/accounts" className="text-primary hover:underline flex items-center gap-2 justify-center">
            <ArrowLeft className="w-4 h-4" /> Kembali ke Daftar Akun
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pt-32 pb-20">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link href="/accounts" className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8">
          <ArrowLeft className="w-4 h-4" /> Kembali ke Daftar Akun
        </Link>

        {/* Image Slider */}
        <div className="relative w-full aspect-video md:aspect-[21/9] bg-card rounded-3xl overflow-hidden border border-white/10 shadow-2xl mb-12">
          {images ? (
            <>
              <img
                src={images[currentImg]}
                alt={`Screenshot ${currentImg + 1}`}
                className="w-full h-full object-cover"
              />

              {images.length > 1 && (
                <>
                  <button
                    onClick={handlePrev}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-black/50 hover:bg-primary/80 text-white flex items-center justify-center backdrop-blur-md transition-all border border-white/10"
                  >
                    <ChevronLeft className="w-6 h-6" />
                  </button>
                  <button
                    onClick={handleNext}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-black/50 hover:bg-primary/80 text-white flex items-center justify-center backdrop-blur-md transition-all border border-white/10"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </button>

                  <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
                    {images.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentImg(i)}
                        className={`h-2 rounded-full transition-all ${
                          currentImg === i ? "bg-primary w-8" : "bg-white/50 w-2 hover:bg-white"
                        }`}
                      />
                    ))}
                  </div>
                </>
              )}
            </>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-black/80">
              <Gamepad2 className="w-20 h-20 text-white/20 mb-4" />
              <p className="text-xl font-display font-bold text-white/50">{account.game}</p>
            </div>
          )}
        </div>

        {/* Details Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-card p-8 rounded-3xl border border-white/5 shadow-xl">
              <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
                <div>
                  <div className="inline-block px-4 py-1.5 rounded-lg bg-primary/10 border border-primary/20 text-primary font-mono font-bold tracking-wider mb-3">
                    {account.unitCode}
                  </div>
                  <h1 className="text-4xl font-display font-black text-white">{account.game}</h1>
                </div>
                <div
                  className={`px-4 py-2 rounded-xl font-bold tracking-wider text-sm ${
                    isSold
                      ? "bg-destructive/20 text-destructive border border-destructive/50"
                      : "bg-green-500/20 text-green-500 border border-green-500/50"
                  }`}
                >
                  {account.status}
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 py-8 border-y border-white/10 mb-8">
                <div>
                  <p className="text-xs text-white/50 uppercase tracking-wider mb-1">Rank / Level</p>
                  <p className="font-bold text-lg text-white">{account.rank}</p>
                </div>
                <div>
                  <p className="text-xs text-white/50 uppercase tracking-wider mb-1">Metode Login</p>
                  <p className="font-bold text-lg text-white">{account.loginMethod}</p>
                </div>
                <div className="sm:col-span-2">
                  <p className="text-xs text-white/50 uppercase tracking-wider mb-1">Harga</p>
                  <p className="font-display font-black text-3xl text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
                    {formatPrice(account.price)}
                  </p>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold text-white mb-4">Deskripsi Akun</h3>
                <div className="text-muted-foreground whitespace-pre-wrap leading-relaxed">
                  {account.description || "Tidak ada deskripsi."}
                </div>
              </div>
            </div>
          </div>

          {/* Buy Section */}
          <div className="space-y-6">
            <div className="bg-card rounded-3xl border border-white/5 p-8 shadow-xl sticky top-24">
              <p className="text-xs text-white/50 uppercase tracking-wider mb-2">Harga</p>
              <p className="font-display font-black text-4xl text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary mb-6">
                {formatPrice(account.price)}
              </p>

              <button
                onClick={handleBuy}
                disabled={isSold}
                data-testid="button-buy-detail"
                className={`w-full py-4 rounded-2xl font-display font-black text-lg transition-all duration-300 mb-4 ${
                  isSold
                    ? "bg-muted text-muted-foreground cursor-not-allowed"
                    : "bg-primary text-black hover:bg-white hover:shadow-[0_0_30px_rgba(0,255,255,0.6)] hover:-translate-y-1"
                }`}
              >
                {isSold ? "AKUN TERJUAL" : (
                  <span className="flex items-center justify-center gap-2">
                    <MessageCircle className="w-5 h-5" />
                    Beli via WhatsApp
                  </span>
                )}
              </button>

              {!isAuthenticated && !isSold && (
                <p className="text-center text-sm text-muted-foreground">
                  <Link href="/login" className="text-primary hover:underline">Login</Link> dahulu untuk membeli
                </p>
              )}

              <div className="mt-6 space-y-3 pt-6 border-t border-white/10">
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <Shield className="w-4 h-4 text-primary flex-shrink-0" />
                  <span>Transaksi aman & bergaransi</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <LogIn className="w-4 h-4 text-secondary flex-shrink-0" />
                  <span>Login via {account.loginMethod}</span>
                </div>
                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                  <ExternalLink className="w-4 h-4 text-accent flex-shrink-0" />
                  <span>Proses melalui WhatsApp</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
