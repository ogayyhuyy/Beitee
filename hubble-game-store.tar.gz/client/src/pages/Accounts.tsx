import { useState, useEffect } from "react";
import { Navbar } from "@/components/Navbar";
import { useQuery } from "@tanstack/react-query";
import { AccountCard } from "@/components/AccountCard";
import { Gamepad2, Filter, SearchX, Info } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { Link, useSearch } from "wouter";

interface GameAccount {
  id: number;
  unitCode: string;
  game: string;
  rank: string;
  price: number;
  loginMethod: string;
  description: string;
  imageUrls: string[];
  status: string;
  createdAt: string;
}

const GAMES = ["Semua", "Mobile Legends", "Free Fire", "The Spike"];
const STATUSES = ["Semua", "TERSEDIA", "SOLD"];

export default function Accounts() {
  const search = useSearch();
  const params = new URLSearchParams(search);
  const initialGame = params.get("game") || "Semua";

  const [selectedGame, setSelectedGame] = useState(initialGame);
  const [selectedStatus, setSelectedStatus] = useState("Semua");
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (initialGame && GAMES.includes(initialGame)) {
      setSelectedGame(initialGame);
    }
  }, [initialGame]);

  const queryParams = new URLSearchParams();
  if (selectedGame !== "Semua") queryParams.set("game", selectedGame);
  if (selectedStatus !== "Semua") queryParams.set("status", selectedStatus);
  const queryString = queryParams.toString();

  const { data, isLoading } = useQuery<{ accounts: GameAccount[] }>({
    queryKey: [`/api/accounts${queryString ? `?${queryString}` : ""}`],
  });
  const accounts = data?.accounts || [];

  return (
    <div className="min-h-screen bg-background pt-32 pb-20">
      <Navbar />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-4xl md:text-5xl font-display font-black text-white mb-4">
            Eksplor <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Akun</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl">
            Temukan akun idamanmu. Gunakan filter di bawah untuk memudahkan pencarian.
          </p>
        </div>

        {!isAuthenticated && (
          <div className="mb-8 p-4 rounded-xl bg-primary/10 border border-primary/20 flex items-center gap-3 text-primary">
            <Info className="w-5 h-5 shrink-0" />
            <p className="text-sm font-medium">
              <Link href="/login" className="underline font-bold hover:text-white transition-colors">Login</Link>{" "}
              atau{" "}
              <Link href="/daftar" className="underline font-bold hover:text-white transition-colors">Daftar</Link>{" "}
              untuk dapat membeli akun.
            </p>
          </div>
        )}

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-6 mb-12 bg-card p-6 rounded-2xl border border-white/5 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl pointer-events-none" />

          <div className="flex-1 relative z-10">
            <label className="text-xs font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Gamepad2 className="w-4 h-4" /> Game
            </label>
            <div className="flex flex-wrap gap-2">
              {GAMES.map((game) => (
                <button
                  key={game}
                  onClick={() => setSelectedGame(game)}
                  data-testid={`button-filter-game-${game.toLowerCase().replace(/\s+/g, '-')}`}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    selectedGame === game
                      ? "bg-primary text-black shadow-[0_0_15px_rgba(0,255,255,0.4)]"
                      : "bg-background border border-white/10 text-muted-foreground hover:border-primary/50 hover:text-white"
                  }`}
                >
                  {game}
                </button>
              ))}
            </div>
          </div>

          <div className="md:w-64 relative z-10">
            <label className="text-xs font-bold text-white/50 uppercase tracking-wider mb-3 flex items-center gap-2">
              <Filter className="w-4 h-4" /> Status
            </label>
            <div className="flex flex-wrap gap-2">
              {STATUSES.map((status) => (
                <button
                  key={status}
                  onClick={() => setSelectedStatus(status)}
                  data-testid={`button-filter-status-${status.toLowerCase()}`}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    selectedStatus === status
                      ? "bg-secondary text-white shadow-[0_0_15px_rgba(157,0,255,0.4)]"
                      : "bg-background border border-white/10 text-muted-foreground hover:border-secondary/50 hover:text-white"
                  }`}
                >
                  {status}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results count */}
        {!isLoading && (
          <p className="text-muted-foreground text-sm mb-6">
            Menampilkan <span className="text-white font-bold">{accounts.length}</span> akun
          </p>
        )}

        {/* Results */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((i) => (
              <div key={i} className="h-[420px] rounded-2xl bg-card animate-pulse border border-white/5" />
            ))}
          </div>
        ) : accounts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {accounts.map((account, index) => (
              <AccountCard key={account.id} account={account} index={index} isAuthenticated={isAuthenticated} />
            ))}
          </div>
        ) : (
          <div className="py-32 flex flex-col items-center justify-center text-center bg-card rounded-3xl border border-white/5">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-6">
              <SearchX className="w-10 h-10 text-primary" />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Tidak Ditemukan</h3>
            <p className="text-muted-foreground max-w-md">
              Maaf, tidak ada akun yang cocok dengan filter yang dipilih. Silakan ubah filter pencarian Anda.
            </p>
            <button
              onClick={() => { setSelectedGame("Semua"); setSelectedStatus("Semua"); }}
              data-testid="button-reset-filter"
              className="mt-8 px-6 py-3 rounded-xl bg-primary/10 text-primary font-bold hover:bg-primary/20 transition-colors"
            >
              Reset Filter
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
