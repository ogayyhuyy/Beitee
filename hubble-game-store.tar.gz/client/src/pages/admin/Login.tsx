import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Gamepad2, Lock, User } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function AdminLogin() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const loginMutation = useMutation({
    mutationFn: (data: { username: string; password: string }) =>
      apiRequest("POST", "/api/admin/login", data),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/admin/me"] });
      toast({ title: "Login Admin Berhasil!" });
      navigate("/admin");
    },
    onError: async (err: any) => {
      const body = err?.body || {};
      toast({
        title: "Login Gagal",
        description: body?.error || "Username atau password salah.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate({ username, password });
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div style={{
          position: "absolute", inset: 0,
          background: "radial-gradient(ellipse at 50% 50%, rgba(157,0,255,0.08) 0%, transparent 60%)"
        }} />
      </div>

      <div className="w-full max-w-md relative z-10">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-secondary to-accent flex items-center justify-center shadow-[0_0_20px_rgba(157,0,255,0.4)] mx-auto mb-4">
            <Lock className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-display font-black text-white">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-2 text-sm">Masuk dengan kredensial admin</p>
        </div>

        <div className="bg-card border border-secondary/20 rounded-2xl p-8 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor="admin-username">
                Username
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  id="admin-username"
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="admin"
                  required
                  data-testid="input-admin-username"
                  className="w-full bg-background border border-white/10 rounded-xl pl-11 pr-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-secondary/50 focus:ring-1 focus:ring-secondary/30 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor="admin-password">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  id="admin-password"
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  data-testid="input-admin-password"
                  className="w-full bg-background border border-white/10 rounded-xl pl-11 pr-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-secondary/50 focus:ring-1 focus:ring-secondary/30 transition-all"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loginMutation.isPending}
              data-testid="button-submit-admin-login"
              className="w-full py-3.5 rounded-xl bg-secondary text-white font-display font-bold text-lg hover:bg-accent hover:shadow-[0_0_20px_rgba(157,0,255,0.5)] transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loginMutation.isPending ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Lock className="w-5 h-5" />
                  Login Admin
                </>
              )}
            </button>
          </form>

        </div>

        <p className="text-center mt-6 text-muted-foreground text-sm">
          <a href="/" className="hover:text-primary transition-colors">Kembali ke Home</a>
        </p>
      </div>
    </div>
  );
}
