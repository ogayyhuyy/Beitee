import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useLocation } from "wouter";
import {
  LayoutDashboard, Package, Plus, Trash2, Edit2, LogOut,
  Gamepad2, CheckCircle2, XCircle, ImagePlus, X, DollarSign, Users
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GameAccount {
  id: number;
  unitCode: string;
  game: string;
  rank: string;
  price: number;
  loginMethod: string;
  description: string;
  imageUrls: string[];
  status: string;
  createdAt: string;
}

const GAMES = ["Mobile Legends", "Free Fire", "The Spike"];
const LOGIN_METHODS = ["Moonton", "Google", "Facebook", "VK", "Guest"];

const EMPTY_FORM = {
  game: GAMES[0],
  rank: "",
  price: "",
  loginMethod: LOGIN_METHODS[0],
  description: "",
  status: "TERSEDIA",
};

export default function AdminDashboard() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [activeTab, setActiveTab] = useState<"dashboard" | "accounts" | "new">("dashboard");
  const [editingAccount, setEditingAccount] = useState<GameAccount | null>(null);
  const [form, setForm] = useState({ ...EMPTY_FORM });
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [uploading, setUploading] = useState(false);

  // Fetch admin auth
  const { data: adminData } = useQuery<{ authenticated: boolean; username?: string }>({
    queryKey: ["/api/admin/me"],
    retry: false,
  });

  // Fetch accounts (all)
  const { data: accountsData, isLoading: accountsLoading } = useQuery<{ accounts: GameAccount[] }>({
    queryKey: ["/api/accounts"],
  });
  const accounts = accountsData?.accounts || [];

  // Stats
  const available = accounts.filter(a => a.status === "TERSEDIA").length;
  const sold = accounts.filter(a => a.status === "SOLD").length;
  const totalRevenue = accounts.filter(a => a.status === "SOLD").reduce((sum, a) => sum + a.price, 0);

  // Logout
  const logoutMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/admin/logout"),
    onSuccess: () => {
      queryClient.clear();
      navigate("/admin/login");
    },
  });

  // Create
  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/admin/accounts", data),
    onSuccess: () => {
      toast({ title: "Akun berhasil ditambahkan!" });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      resetForm();
      setActiveTab("accounts");
    },
    onError: async (err: any) => {
      const body = err?.body || {};
      toast({ title: "Error", description: body?.error || "Gagal menambah akun.", variant: "destructive" });
    },
  });

  // Update
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => apiRequest("PATCH", `/api/admin/accounts/${id}`, data),
    onSuccess: () => {
      toast({ title: "Akun berhasil diupdate!" });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      resetForm();
      setEditingAccount(null);
      setActiveTab("accounts");
    },
    onError: async (err: any) => {
      const body = err?.body || {};
      toast({ title: "Error", description: body?.error || "Gagal update akun.", variant: "destructive" });
    },
  });

  // Delete
  const deleteMutation = useMutation({
    mutationFn: (id: number) => apiRequest("DELETE", `/api/admin/accounts/${id}`),
    onSuccess: () => {
      toast({ title: "Akun berhasil dihapus!" });
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
    },
    onError: async (err: any) => {
      const body = err?.body || {};
      toast({ title: "Error", description: body?.error || "Gagal hapus akun.", variant: "destructive" });
    },
  });

  const resetForm = () => {
    setForm({ ...EMPTY_FORM });
    setUploadedImages([]);
    setEditingAccount(null);
  };

  const startEdit = (account: GameAccount) => {
    setEditingAccount(account);
    setForm({
      game: account.game,
      rank: account.rank,
      price: String(account.price),
      loginMethod: account.loginMethod,
      description: account.description || "",
      status: account.status,
    });
    setUploadedImages(account.imageUrls || []);
    setActiveTab("new");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...form,
      price: Number(form.price),
      imageUrls: uploadedImages,
    };
    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data: payload });
    } else {
      createMutation.mutate(payload);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setUploading(true);
    try {
      const urls: string[] = [];
      for (const file of files) {
        const formData = new FormData();
        formData.append("image", file);
        const res = await fetch("/api/admin/upload", { method: "POST", body: formData });
        const data = await res.json();
        if (data.url) urls.push(data.url);
      }
      setUploadedImages(prev => [...prev, ...urls]);
    } catch {
      toast({ title: "Upload gagal", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const removeImage = (idx: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== idx));
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(price);
  };

  // Redirect if not admin
  if (!adminData?.authenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Silakan login sebagai admin</p>
          <a href="/admin/login" className="text-primary hover:underline">Login Admin</a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className="w-64 bg-card border-r border-white/5 flex flex-col fixed h-full z-30">
        <div className="p-6 border-b border-white/5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-secondary to-accent flex items-center justify-center">
              <Gamepad2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-display font-bold text-white text-sm">Hubble Admin</p>
              <p className="text-xs text-muted-foreground">{adminData.username}</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-4 space-y-1">
          {[
            { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
            { id: "accounts", label: "Daftar Akun", icon: Package },
            { id: "new", label: "Tambah Akun", icon: Plus },
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => {
                if (id === "new") resetForm();
                setActiveTab(id as any);
              }}
              data-testid={`button-nav-${id}`}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-semibold transition-all text-sm ${
                activeTab === id
                  ? "bg-secondary/20 text-secondary border border-secondary/20"
                  : "text-muted-foreground hover:bg-white/5 hover:text-white"
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-white/5">
          <a href="/" className="flex items-center gap-3 px-4 py-3 rounded-xl text-muted-foreground hover:bg-white/5 hover:text-white transition-all text-sm font-semibold mb-2">
            <Gamepad2 className="w-4 h-4" />
            Lihat Store
          </a>
          <button
            onClick={() => logoutMutation.mutate()}
            data-testid="button-admin-logout"
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-destructive hover:bg-destructive/10 transition-all text-sm font-semibold"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 ml-64 p-8 overflow-auto">
        {/* Dashboard Tab */}
        {activeTab === "dashboard" && (
          <div>
            <h1 className="text-3xl font-display font-black text-white mb-8">Dashboard</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
              {[
                { label: "Total Akun", value: accounts.length, icon: Package, color: "primary", glow: "rgba(0,255,255,0.15)" },
                { label: "Tersedia", value: available, icon: CheckCircle2, color: "green", glow: "rgba(34,197,94,0.15)" },
                { label: "Terjual", value: sold, icon: XCircle, color: "destructive", glow: "rgba(239,68,68,0.15)" },
                { label: "Total Revenue", value: formatPrice(totalRevenue), icon: DollarSign, color: "secondary", glow: "rgba(157,0,255,0.15)" },
              ].map((stat, i) => (
                <div
                  key={i}
                  className="bg-card rounded-2xl border border-white/5 p-6"
                  data-testid={`stat-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                      <stat.icon className="w-5 h-5 text-primary" />
                    </div>
                  </div>
                  <p className="text-2xl font-display font-black text-white">{stat.value}</p>
                  <p className="text-muted-foreground text-sm mt-1">{stat.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-card rounded-2xl border border-white/5 p-6">
              <h2 className="text-xl font-display font-bold text-white mb-6">Akun Terbaru</h2>
              {accounts.slice(0, 5).map(a => (
                <div key={a.id} className="flex items-center justify-between py-3 border-b border-white/5 last:border-0">
                  <div>
                    <p className="font-semibold text-white">{a.unitCode} - {a.game}</p>
                    <p className="text-sm text-muted-foreground">{a.rank} · {formatPrice(a.price)}</p>
                  </div>
                  <span className={`text-xs font-bold px-3 py-1 rounded-lg ${a.status === "TERSEDIA" ? "bg-green-500/20 text-green-400" : "bg-destructive/20 text-destructive"}`}>
                    {a.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Accounts List Tab */}
        {activeTab === "accounts" && (
          <div>
            <div className="flex items-center justify-between mb-8">
              <h1 className="text-3xl font-display font-black text-white">Daftar Akun</h1>
              <button
                onClick={() => { resetForm(); setActiveTab("new"); }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-black font-bold hover:bg-white transition-all"
              >
                <Plus className="w-4 h-4" />
                Tambah Baru
              </button>
            </div>

            {accountsLoading ? (
              <div className="space-y-4">
                {[1,2,3].map(i => <div key={i} className="h-24 bg-card rounded-xl animate-pulse border border-white/5" />)}
              </div>
            ) : accounts.length === 0 ? (
              <div className="text-center py-20 bg-card rounded-2xl border border-white/5">
                <Package className="w-16 h-16 text-primary/30 mx-auto mb-4" />
                <p className="text-xl text-muted-foreground">Belum ada akun.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {accounts.map(account => (
                  <div key={account.id} className="bg-card rounded-2xl border border-white/5 p-5 flex items-center gap-4 flex-wrap" data-testid={`row-account-${account.id}`}>
                    <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                      <Gamepad2 className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-white">{account.unitCode} — {account.game}</p>
                      <p className="text-sm text-muted-foreground">Rank: {account.rank} · Login: {account.loginMethod} · {formatPrice(account.price)}</p>
                    </div>
                    <span className={`text-xs font-bold px-3 py-1 rounded-lg ${account.status === "TERSEDIA" ? "bg-green-500/20 text-green-400" : "bg-destructive/20 text-destructive"}`}>
                      {account.status}
                    </span>
                    <div className="flex gap-2">
                      <button
                        onClick={() => startEdit(account)}
                        data-testid={`button-edit-${account.id}`}
                        className="p-2 rounded-xl bg-secondary/10 text-secondary hover:bg-secondary/20 transition-all"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm("Hapus akun ini?")) deleteMutation.mutate(account.id);
                        }}
                        data-testid={`button-delete-${account.id}`}
                        className="p-2 rounded-xl bg-destructive/10 text-destructive hover:bg-destructive/20 transition-all"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* New/Edit Account Form Tab */}
        {activeTab === "new" && (
          <div>
            <div className="flex items-center gap-4 mb-8">
              <h1 className="text-3xl font-display font-black text-white">
                {editingAccount ? `Edit: ${editingAccount.unitCode}` : "Tambah Akun Baru"}
              </h1>
              {editingAccount && (
                <button onClick={resetForm} className="text-xs text-muted-foreground hover:text-white flex items-center gap-1">
                  <X className="w-3 h-3" /> Batal Edit
                </button>
              )}
            </div>

            <form onSubmit={handleSubmit} className="max-w-2xl space-y-6">
              <div className="bg-card rounded-2xl border border-white/5 p-8 space-y-6">
                {/* Game */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Game *</label>
                  <select
                    value={form.game}
                    onChange={e => setForm(p => ({ ...p, game: e.target.value }))}
                    data-testid="select-game"
                    className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-all"
                  >
                    {GAMES.map(g => <option key={g} value={g}>{g}</option>)}
                  </select>
                </div>

                {/* Rank */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Rank / Level *</label>
                  <input
                    type="text"
                    value={form.rank}
                    onChange={e => setForm(p => ({ ...p, rank: e.target.value }))}
                    placeholder="e.g. Mythical Glory, Grand Master, etc."
                    required
                    data-testid="input-rank"
                    className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 transition-all"
                  />
                </div>

                {/* Login Method */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Metode Login *</label>
                  <select
                    value={form.loginMethod}
                    onChange={e => setForm(p => ({ ...p, loginMethod: e.target.value }))}
                    data-testid="select-login-method"
                    className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-primary/50 transition-all"
                  >
                    {LOGIN_METHODS.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>

                {/* Price */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Harga (IDR) *</label>
                  <input
                    type="number"
                    value={form.price}
                    onChange={e => setForm(p => ({ ...p, price: e.target.value }))}
                    placeholder="e.g. 150000"
                    required
                    min={1000}
                    data-testid="input-price"
                    className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 transition-all"
                  />
                </div>

                {/* Status */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Status</label>
                  <div className="flex gap-3">
                    {["TERSEDIA", "SOLD"].map(s => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setForm(p => ({ ...p, status: s }))}
                        className={`flex-1 py-2.5 rounded-xl font-bold text-sm transition-all ${
                          form.status === s
                            ? s === "TERSEDIA"
                              ? "bg-green-500/20 text-green-400 border border-green-500/50"
                              : "bg-destructive/20 text-destructive border border-destructive/50"
                            : "bg-background border border-white/10 text-muted-foreground hover:border-white/30"
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Description */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Deskripsi</label>
                  <textarea
                    value={form.description}
                    onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                    rows={5}
                    placeholder="Tulis deskripsi lengkap akun (hero yang ada, skin, dll)..."
                    data-testid="input-description"
                    className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 transition-all resize-none"
                  />
                </div>

                {/* Image Upload */}
                <div>
                  <label className="text-sm font-semibold text-white/70 block mb-2">Gambar/Screenshot</label>
                  <label className="flex flex-col items-center gap-3 p-8 border-2 border-dashed border-white/10 rounded-xl cursor-pointer hover:border-primary/30 hover:bg-primary/5 transition-all">
                    <ImagePlus className="w-8 h-8 text-primary/50" />
                    <span className="text-sm text-muted-foreground">
                      {uploading ? "Mengupload..." : "Klik untuk upload gambar"}
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handleImageUpload}
                      className="hidden"
                      data-testid="input-images"
                    />
                  </label>

                  {uploadedImages.length > 0 && (
                    <div className="grid grid-cols-3 gap-3 mt-4">
                      {uploadedImages.map((url, i) => (
                        <div key={i} className="relative group aspect-video rounded-xl overflow-hidden bg-black">
                          <img src={url} alt={`img-${i}`} className="w-full h-full object-cover" />
                          <button
                            type="button"
                            onClick={() => removeImage(i)}
                            className="absolute inset-0 bg-black/60 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="w-6 h-6 text-destructive" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Submit */}
              <div className="flex gap-4">
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-account"
                  className="flex-1 py-4 rounded-xl bg-primary text-black font-display font-black text-lg hover:bg-white hover:shadow-[0_0_20px_rgba(0,255,255,0.5)] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {createMutation.isPending || updateMutation.isPending ? (
                    <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                  ) : editingAccount ? (
                    <><Edit2 className="w-5 h-5" /> Simpan Perubahan</>
                  ) : (
                    <><Plus className="w-5 h-5" /> Tambah Akun</>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => { resetForm(); setActiveTab("accounts"); }}
                  className="px-6 rounded-xl bg-card border border-white/10 text-white font-bold hover:border-white/30 transition-all"
                >
                  Batal
                </button>
              </div>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
