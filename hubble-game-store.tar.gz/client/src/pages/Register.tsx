import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Gamepad2, UserPlus, Eye, EyeOff } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Register() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [form, setForm] = useState({
    username: "",
    email: "",
    whatsapp: "",
    password: "",
    confirmPassword: "",
  });
  const [showPass, setShowPass] = useState(false);

  const registerMutation = useMutation({
    mutationFn: (data: typeof form) => apiRequest("POST", "/api/auth/register", data),
    onSuccess: () => {
      toast({ title: "Registrasi Berhasil!", description: "Silakan login dengan akun Anda." });
      navigate("/login");
    },
    onError: async (err: any) => {
      const body = err?.body || {};
      toast({
        title: "Registrasi Gagal",
        description: body?.error || "Terjadi kesalahan. Coba lagi.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      toast({ title: "Error", description: "Password dan konfirmasi tidak sama.", variant: "destructive" });
      return;
    }
    if (form.password.length < 6) {
      toast({ title: "Error", description: "Password minimal 6 karakter.", variant: "destructive" });
      return;
    }
    registerMutation.mutate(form);
  };

  const handleChange = (field: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm(prev => ({ ...prev, [field]: e.target.value }));
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 py-16">
      {/* Background */}
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div style={{
          position: "absolute", inset: 0,
          background: "radial-gradient(ellipse at 20% 40%, rgba(0,255,255,0.08) 0%, transparent 50%), radial-gradient(ellipse at 80% 60%, rgba(157,0,255,0.08) 0%, transparent 50%)"
        }} />
      </div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="inline-flex items-center gap-3 group">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-[0_0_20px_rgba(0,255,255,0.4)]">
              <Gamepad2 className="w-7 h-7 text-black" />
            </div>
            <span className="font-display font-black text-3xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              HUBBLE
            </span>
          </Link>
          <p className="text-muted-foreground mt-2">Daftar akun baru</p>
        </div>

        {/* Form Card */}
        <div className="bg-card border border-white/10 rounded-2xl p-8 shadow-2xl">
          <h2 className="text-2xl font-display font-bold text-white mb-6">Buat Akun</h2>

          <form onSubmit={handleSubmit} className="space-y-4">
            {[
              { field: "username" as const, label: "Username", type: "text", placeholder: "username_kamu", testId: "input-username" },
              { field: "email" as const, label: "Email", type: "email", placeholder: "email@example.com", testId: "input-email" },
              { field: "whatsapp" as const, label: "Nomor WhatsApp", type: "tel", placeholder: "08xxxxxxxxxx", testId: "input-whatsapp" },
            ].map(({ field, label, type, placeholder, testId }) => (
              <div key={field}>
                <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor={field}>
                  {label}
                </label>
                <input
                  id={field}
                  type={type}
                  value={form[field]}
                  onChange={handleChange(field)}
                  placeholder={placeholder}
                  required
                  data-testid={testId}
                  className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-all"
                />
              </div>
            ))}

            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor="password">
                Password
              </label>
              <div className="relative">
                <input
                  id="password"
                  type={showPass ? "text" : "password"}
                  value={form.password}
                  onChange={handleChange("password")}
                  placeholder="Minimal 6 karakter"
                  required
                  data-testid="input-password"
                  className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 pr-12 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-white transition-colors"
                >
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="text-sm font-semibold text-white/70 block mb-2" htmlFor="confirmPassword">
                Konfirmasi Password
              </label>
              <input
                id="confirmPassword"
                type="password"
                value={form.confirmPassword}
                onChange={handleChange("confirmPassword")}
                placeholder="Ulangi password"
                required
                data-testid="input-confirm-password"
                className="w-full bg-background border border-white/10 rounded-xl px-4 py-3 text-white placeholder-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/30 transition-all"
              />
            </div>

            <button
              type="submit"
              disabled={registerMutation.isPending}
              data-testid="button-submit-register"
              className="w-full py-3.5 rounded-xl bg-primary text-black font-display font-bold text-lg hover:bg-white hover:shadow-[0_0_20px_rgba(0,255,255,0.5)] transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-6"
            >
              {registerMutation.isPending ? (
                <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
              ) : (
                <>
                  <UserPlus className="w-5 h-5" />
                  Daftar Sekarang
                </>
              )}
            </button>
          </form>

          <p className="mt-6 text-center text-muted-foreground text-sm">
            Sudah punya akun?{" "}
            <Link href="/login" className="text-primary font-bold hover:underline">
              Login di sini
            </Link>
          </p>
        </div>

        <p className="text-center mt-6 text-muted-foreground text-sm">
          <Link href="/" className="hover:text-primary transition-colors">Kembali ke Home</Link>
        </p>
      </div>
    </div>
  );
}
