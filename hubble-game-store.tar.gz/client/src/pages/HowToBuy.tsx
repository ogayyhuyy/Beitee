import { Navbar } from "@/components/Navbar";
import { Link } from "wouter";
import { Search, MessageCircle, ShieldCheck, ArrowRight, Gamepad2, CheckCircle2 } from "lucide-react";

export default function HowToBuy() {
  const steps = [
    {
      step: "01",
      icon: Search,
      title: "Pilih Akun Game",
      desc: "Browse daftar akun yang tersedia. Gunakan filter berdasarkan game, rank, dan status untuk menemukan akun yang sesuai dengan kebutuhan Anda.",
      color: "primary",
      glow: "rgba(0,255,255,0.15)"
    },
    {
      step: "02",
      icon: ShieldCheck,
      title: "Daftar / Login",
      desc: "Buat akun di Hubble Store atau login jika sudah punya. Akun diperlukan untuk dapat menghubungi admin dan melakukan pembelian.",
      color: "secondary",
      glow: "rgba(157,0,255,0.15)"
    },
    {
      step: "03",
      icon: MessageCircle,
      title: "Hubungi Admin via WhatsApp",
      desc: "Klik tombol 'Beli via WhatsApp' pada halaman detail akun. Admin kami akan merespons secepat mungkin untuk memproses transaksi Anda.",
      color: "accent",
      glow: "rgba(255,0,255,0.15)"
    },
    {
      step: "04",
      icon: CheckCircle2,
      title: "Selesaikan Pembayaran",
      desc: "Ikuti instruksi dari admin untuk menyelesaikan pembayaran. Setelah pembayaran dikonfirmasi, akun langsung diserahterimakan.",
      color: "primary",
      glow: "rgba(0,255,255,0.15)"
    },
  ];

  const faqs = [
    {
      q: "Apakah transaksi dijamin aman?",
      a: "Ya, semua transaksi dijamin aman. Kami hanya akan menyerahkan akun setelah pembayaran berhasil dikonfirmasi."
    },
    {
      q: "Berapa lama proses pembelian?",
      a: "Proses pembelian biasanya memakan waktu 5-15 menit setelah pembayaran dikonfirmasi. Admin kami siap melayani 24/7."
    },
    {
      q: "Metode pembayaran apa yang diterima?",
      a: "Kami menerima transfer bank, dompet digital (GoPay, OVO, Dana), dan metode pembayaran populer lainnya yang akan dikonfirmasi via WhatsApp."
    },
    {
      q: "Bagaimana jika ada masalah setelah pembelian?",
      a: "Hubungi admin kami segera via WhatsApp. Kami memberikan garansi dan siap membantu menyelesaikan masalah apapun."
    },
    {
      q: "Apakah akun sudah diverifikasi?",
      a: "Ya, setiap akun yang kami jual telah melalui proses verifikasi ketat untuk memastikan keaslian dan kualitasnya."
    },
  ];

  return (
    <div className="min-h-screen bg-background pt-32 pb-20">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary mb-8">
            <Gamepad2 className="w-4 h-4" />
            <span className="text-sm font-bold tracking-wider uppercase">Panduan Pembelian</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-display font-black text-white mb-6">
            Cara <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">Membeli</span>
          </h1>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Proses pembelian akun di Hubble Store sangat mudah dan cepat. Ikuti langkah-langkah berikut.
          </p>
        </div>

        {/* Steps */}
        <div className="space-y-6 mb-24 relative">
          <div className="absolute left-[3.5rem] top-16 bottom-16 w-px bg-gradient-to-b from-primary/30 via-secondary/30 to-accent/30 hidden md:block" />

          {steps.map((step, i) => (
            <div
              key={i}
              className="relative bg-card rounded-2xl border border-white/5 p-8 flex items-start gap-8 transition-all duration-300 group hover:border-white/15"
              style={{ transition: "all 0.3s ease" }}
              onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = `0 0 30px ${step.glow}`; }}
              onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "none"; }}
            >
              <div className="hidden md:flex flex-shrink-0 w-14 h-14 rounded-xl items-center justify-center bg-card border border-white/10 relative z-10">
                <step.icon className="w-7 h-7 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-4 mb-3">
                  <div className="md:hidden w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                    <step.icon className="w-5 h-5 text-primary" />
                  </div>
                  <span className="font-mono text-xs font-bold text-primary/50 tracking-widest">LANGKAH {step.step}</span>
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-3">{step.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="relative overflow-hidden bg-card rounded-3xl border border-primary/20 p-12 text-center mb-24">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-secondary/5 pointer-events-none" />
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-secondary/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <h2 className="text-3xl font-display font-black text-white mb-4">Siap Memulai?</h2>
            <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
              Browse koleksi akun game kami sekarang dan temukan akun idamanmu!
            </p>
            <Link
              href="/accounts"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-primary text-black font-bold text-lg hover:bg-white hover:shadow-[0_0_30px_rgba(0,255,255,0.6)] transition-all duration-300 hover:-translate-y-1"
            >
              Eksplor Akun <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>

        {/* FAQ */}
        <div>
          <h2 className="text-3xl font-display font-bold text-white mb-10 text-center">
            Pertanyaan <span className="text-primary">Umum</span>
          </h2>
          <div className="space-y-4">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-card rounded-2xl border border-white/5 p-6">
                <h3 className="font-bold text-white mb-3 text-lg">{faq.q}</h3>
                <p className="text-muted-foreground leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
