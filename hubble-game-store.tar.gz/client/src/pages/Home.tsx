import { Navbar } from "@/components/Navbar";
import { Link } from "wouter";
import { ArrowRight, Zap, ShieldCheck, Clock, Gamepad2, Star } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { AccountCard } from "@/components/AccountCard";
import { useAuth } from "@/context/AuthContext";

interface GameAccount {
  id: number;
  unitCode: string;
  game: string;
  rank: string;
  price: number;
  loginMethod: string;
  description: string;
  imageUrls: string[];
  status: string;
  createdAt: string;
}

export default function Home() {
  const { data, isLoading } = useQuery<{ accounts: GameAccount[] }>({
    queryKey: ["/api/accounts?status=TERSEDIA"],
  });
  const featuredAccounts = data?.accounts?.slice(0, 3) || [];
  const { isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0" style={{
            backgroundImage: `
              radial-gradient(ellipse at 20% 40%, rgba(0, 255, 255, 0.12) 0%, transparent 50%),
              radial-gradient(ellipse at 80% 20%, rgba(157, 0, 255, 0.12) 0%, transparent 50%),
              radial-gradient(ellipse at 50% 80%, rgba(0, 100, 255, 0.08) 0%, transparent 50%)
            `
          }} />
          <div className="absolute inset-0 bg-gradient-to-b from-background/20 via-background/70 to-background" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 text-primary mb-8">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-bold tracking-wider uppercase">Marketplace Akun Game #1</span>
            </div>

            <h1 className="text-5xl md:text-7xl font-display font-black text-white mb-8 leading-tight">
              ELEVATE YOUR <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-primary">
                GAMING EXPERIENCE
              </span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              Beli akun Mobile Legends, Free Fire, dan The Spike dengan aman, cepat, dan terpercaya. Stok berkualitas dengan harga kompetitif.
            </p>

            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link
                href="/accounts"
                data-testid="link-explore-accounts"
                className="px-8 py-4 rounded-xl bg-primary text-black font-bold text-lg hover:bg-white hover:shadow-[0_0_30px_rgba(0,255,255,0.6)] transition-all duration-300 flex items-center justify-center gap-2 hover:-translate-y-1"
              >
                Eksplor Akun <ArrowRight className="w-5 h-5" />
              </Link>
              <Link
                href="/cara-beli"
                data-testid="link-how-to-buy"
                className="px-8 py-4 rounded-xl bg-card border border-white/10 text-white font-bold text-lg hover:border-primary/50 hover:bg-primary/5 transition-all duration-300 flex items-center justify-center gap-2"
              >
                Cara Membeli
              </Link>
            </div>
          </div>
        </div>

        {/* Floating orbs decoration */}
        <div className="absolute top-20 left-10 w-64 h-64 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-20 right-10 w-64 h-64 bg-secondary/5 rounded-full blur-3xl pointer-events-none" />
      </section>

      {/* Stats Bar */}
      <section className="py-8 border-y border-white/5 bg-black/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-3 gap-4 text-center">
            {[
              { value: "500+", label: "Akun Terjual" },
              { value: "3", label: "Game Tersedia" },
              { value: "100%", label: "Garansi Aman" },
            ].map((stat, i) => (
              <div key={i} className="py-4">
                <p className="text-2xl md:text-3xl font-display font-black text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">{stat.value}</p>
                <p className="text-sm text-muted-foreground mt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: ShieldCheck,
                title: "100% Aman & Garansi",
                desc: "Setiap akun yang dijual telah melalui proses pengecekan ketat. Garansi penuh untuk setiap transaksi.",
                color: "from-primary to-primary",
                glow: "rgba(0,255,255,0.2)"
              },
              {
                icon: Zap,
                title: "Proses Instan",
                desc: "Transaksi langsung via WhatsApp tanpa perantara yang ribet. Akun langsung di tangan Anda.",
                color: "from-secondary to-secondary",
                glow: "rgba(157,0,255,0.2)"
              },
              {
                icon: Clock,
                title: "Support 24/7",
                desc: "Admin siap melayani pertanyaan dan keluhan Anda kapan saja, siang dan malam.",
                color: "from-accent to-accent",
                glow: "rgba(255,0,255,0.2)"
              },
            ].map((feature, i) => (
              <div
                key={i}
                className="bg-card/50 backdrop-blur-sm p-8 rounded-2xl border border-white/5 hover:border-primary/30 transition-all duration-300 group relative overflow-hidden"
                style={{
                  boxShadow: `0 0 0 transparent`,
                  transition: "all 0.3s ease"
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLElement).style.boxShadow = `0 0 30px ${feature.glow}`;
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLElement).style.boxShadow = "0 0 0 transparent";
                }}
              >
                <div className="absolute top-0 right-0 w-32 h-32 rounded-full blur-3xl pointer-events-none" style={{ background: feature.glow, opacity: 0.3 }} />
                <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform relative z-10">
                  <feature.icon className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-display font-bold text-white mb-3 relative z-10">{feature.title}</h3>
                <p className="text-muted-foreground relative z-10">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Accounts */}
      <section className="py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-display font-bold text-white mb-4">
                Akun <span className="text-primary">Terbaru</span>
              </h2>
              <p className="text-muted-foreground">Pilihan akun gaming terbaik yang baru saja mendarat.</p>
            </div>
            <Link href="/accounts" className="hidden sm:flex text-primary hover:text-white transition-colors items-center gap-1 font-semibold">
              Lihat Semua <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-[450px] rounded-2xl bg-card animate-pulse border border-white/5" />
              ))}
            </div>
          ) : featuredAccounts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredAccounts.map((account, index) => (
                <AccountCard key={account.id} account={account} index={index} isAuthenticated={isAuthenticated} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20 bg-card rounded-2xl border border-white/5">
              <Gamepad2 className="w-16 h-16 text-primary/30 mx-auto mb-4" />
              <p className="text-xl text-muted-foreground">Belum ada akun yang tersedia saat ini.</p>
            </div>
          )}

          <div className="mt-8 text-center sm:hidden">
            <Link href="/accounts" className="inline-flex text-primary hover:text-white transition-colors items-center gap-1 font-semibold">
              Lihat Semua Akun <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Games Section */}
      <section className="py-20 bg-black/20 border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-display font-bold text-white mb-12 text-center">Game Yang Tersedia</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              {
                name: "Mobile Legends",
                desc: "Akun dengan berbagai rank dari Classic hingga Mythical Glory",
                color: "from-blue-600 to-blue-400",
                glow: "rgba(59,130,246,0.3)"
              },
              {
                name: "Free Fire",
                desc: "Akun dengan berbagai item rare, karakter, dan skin eksklusif",
                color: "from-orange-600 to-yellow-400",
                glow: "rgba(249,115,22,0.3)"
              },
              {
                name: "The Spike",
                desc: "Akun dengan berbagai karakter dan kostum spesial",
                color: "from-purple-600 to-pink-400",
                glow: "rgba(168,85,247,0.3)"
              },
            ].map((game, i) => (
              <Link
                key={i}
                href={`/accounts?game=${encodeURIComponent(game.name)}`}
                className="group relative overflow-hidden bg-card rounded-2xl border border-white/5 hover:border-white/20 p-8 transition-all duration-300"
                style={{ boxShadow: "0 0 0 transparent", transition: "all 0.3s ease" }}
                onMouseEnter={e => { (e.currentTarget as HTMLElement).style.boxShadow = `0 0 30px ${game.glow}`; }}
                onMouseLeave={e => { (e.currentTarget as HTMLElement).style.boxShadow = "0 0 0 transparent"; }}
              >
                <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ background: `radial-gradient(circle at top right, ${game.glow} 0%, transparent 60%)` }} />
                <div className={`text-5xl font-display font-black mb-4 bg-clip-text text-transparent bg-gradient-to-r ${game.color}`}>
                  {game.name.split(" ")[0]}
                </div>
                <p className="font-bold text-xl text-white mb-2">{game.name}</p>
                <p className="text-muted-foreground text-sm mb-6">{game.desc}</p>
                <div className={`inline-flex items-center gap-2 text-sm font-bold bg-clip-text text-transparent bg-gradient-to-r ${game.color}`}>
                  Lihat Akun <ArrowRight className="w-4 h-4" style={{ color: "inherit" }} />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial Preview */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-display font-bold text-white mb-4">
            Apa Kata <span className="text-primary">Pembeli</span>?
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Bergabunglah dengan ratusan gamer yang telah mempercayakan kebutuhan akun game mereka kepada kami.
          </p>
          <Link
            href="/testimoni"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-card border border-white/10 text-white font-bold hover:border-primary/50 hover:bg-primary/5 transition-all"
          >
            <Star className="w-4 h-4 text-primary" />
            Lihat Semua Testimoni
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black py-12 border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center items-center gap-2 mb-6">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center">
              <Gamepad2 className="w-5 h-5 text-black" />
            </div>
            <span className="font-display font-bold text-xl text-white">HUBBLE STORE</span>
          </div>
          <p className="text-muted-foreground mb-8">Premium Game Account Marketplace.</p>
          <div className="flex justify-center gap-6 text-sm text-muted-foreground">
            <Link href="/" className="hover:text-primary transition-colors">Home</Link>
            <Link href="/accounts" className="hover:text-primary transition-colors">Daftar Akun</Link>
            <Link href="/cara-beli" className="hover:text-primary transition-colors">Cara Beli</Link>
            <Link href="/testimoni" className="hover:text-primary transition-colors">Testimoni</Link>
          </div>
          <p className="text-xs text-white/20 mt-12">© {new Date().getFullYear()} Hubble Store. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
