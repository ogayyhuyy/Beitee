import { useState } from "react";
import { Link } from "wouter";
import { Sparkles, ChevronLeft, ChevronRight, Gamepad2, Shield, LogIn } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GameAccount {
  id: number;
  unitCode: string;
  game: string;
  rank: string;
  price: number;
  loginMethod: string;
  description: string;
  imageUrls: string[];
  status: string;
  createdAt: string;
}

interface AccountCardProps {
  account: GameAccount;
  index?: number;
  isAuthenticated?: boolean;
}

export function AccountCard({ account, index = 0, isAuthenticated = false }: AccountCardProps) {
  const isSold = account.status === "SOLD";
  const { toast } = useToast();
  const [currentImg, setCurrentImg] = useState(0);

  const images = account.imageUrls && account.imageUrls.length > 0 ? account.imageUrls : null;

  const handleNext = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (images) setCurrentImg((prev) => (prev + 1) % images.length);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (images) setCurrentImg((prev) => (prev - 1 + images.length) % images.length);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const handleBuy = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (isSold) return;

    if (!isAuthenticated) {
      toast({
        title: "Akses Ditolak",
        description: "Silakan login atau daftar terlebih dahulu untuk membeli akun.",
        variant: "destructive",
      });
      return;
    }

    const message = `Halo admin Hubble Store\nSaya ingin membeli akun.\n\nKode Unit: ${account.unitCode}\nGame: ${account.game}`;
    const url = `https://wa.me/6281229314973?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank");
  };

  return (
    <div
      className={`group relative overflow-hidden rounded-2xl bg-card border flex flex-col h-full transition-all duration-500 ${
        isSold
          ? "border-destructive/30 opacity-75"
          : "border-primary/20 hover:border-primary/50"
      }`}
      style={!isSold ? { boxShadow: "0 0 0 transparent" } : undefined}
      data-testid={`card-account-${account.id}`}
    >
      <Link href={`/accounts/${account.id}`} className="flex-1 flex flex-col h-full cursor-pointer">
        {/* Image Container */}
        <div className="relative aspect-video overflow-hidden bg-black flex-shrink-0">
          {images ? (
            <img
              src={images[currentImg]}
              alt={account.unitCode}
              className="object-cover w-full h-full opacity-80 group-hover:opacity-100 group-hover:scale-105 transition-all duration-700"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-black/80">
              <Gamepad2 className="w-12 h-12 text-white/20 mb-2" />
              <p className="text-sm font-bold text-white/50">{account.game}</p>
            </div>
          )}

          <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />

          {/* Slider Controls */}
          {images && images.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 hover:bg-primary/80 text-white flex items-center justify-center backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all border border-white/10 z-20"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 hover:bg-primary/80 text-white flex items-center justify-center backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all border border-white/10 z-20"
              >
                <ChevronRight className="w-4 h-4" />
              </button>

              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-20">
                {images.map((_, i) => (
                  <div
                    key={i}
                    className={`h-1.5 rounded-full transition-all ${
                      currentImg === i ? "bg-primary w-4" : "bg-white/50 w-1.5"
                    }`}
                  />
                ))}
              </div>
            </>
          )}

          {/* Unit Code Badge */}
          <div className="absolute top-3 left-3 px-3 py-1 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 flex items-center gap-2 z-10">
            <Sparkles className="w-3.5 h-3.5 text-secondary" />
            <span className="font-display font-bold text-xs tracking-wider text-white">
              {account.unitCode}
            </span>
          </div>

          {/* Status Badge */}
          <div
            className={`absolute top-3 right-3 px-3 py-1 rounded-lg border font-bold text-xs tracking-wider backdrop-blur-md z-10 ${
              isSold
                ? "bg-destructive/20 border-destructive text-destructive"
                : "bg-primary/20 border-primary text-primary"
            }`}
          >
            {account.status}
          </div>
        </div>

        {/* Content */}
        <div className="p-5 flex flex-col flex-1 relative z-10">
          <h3 className="font-display font-bold text-lg text-white mb-1 group-hover:text-primary transition-colors">
            {account.game}
          </h3>

          <div className="space-y-2 mt-3 mb-5">
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                <Shield className="w-3.5 h-3.5 text-primary" />
              </div>
              <span className="truncate">Rank: <span className="text-white font-semibold">{account.rank}</span></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <div className="w-7 h-7 rounded-lg bg-secondary/10 flex items-center justify-center flex-shrink-0">
                <LogIn className="w-3.5 h-3.5 text-secondary" />
              </div>
              <span className="truncate">Login: <span className="text-white font-semibold">{account.loginMethod}</span></span>
            </div>
          </div>

          <div className="mt-auto pt-4 border-t border-white/5 flex items-center justify-between gap-3">
            <p className="font-display font-black text-xl text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              {formatPrice(account.price)}
            </p>
            <button
              onClick={handleBuy}
              disabled={isSold}
              data-testid={`button-buy-${account.id}`}
              className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${
                isSold
                  ? "bg-muted text-muted-foreground cursor-not-allowed"
                  : "bg-primary text-black hover:bg-white hover:shadow-[0_0_15px_rgba(0,255,255,0.4)]"
              }`}
            >
              {isSold ? "SOLD" : "Beli"}
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
}
