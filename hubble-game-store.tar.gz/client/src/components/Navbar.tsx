import { Link, useLocation } from "wouter";
import { Gamepad2, Menu, X, User, LogOut, LogIn, UserPlus } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/context/AuthContext";

export function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  const links = [
    { href: "/", label: "Home" },
    { href: "/accounts", label: "Daftar Akun" },
    { href: "/cara-beli", label: "Cara Beli" },
    { href: "/testimoni", label: "Testimoni" },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 bg-glass border-b border-primary/20 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-3 group" data-testid="link-logo">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-[0_0_15px_rgba(0,255,255,0.4)] group-hover:shadow-[0_0_25px_rgba(157,0,255,0.6)] transition-all duration-300">
              <Gamepad2 className="w-6 h-6 text-black" />
            </div>
            <span className="font-display font-black text-2xl tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary">
              HUBBLE
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                data-testid={`link-nav-${link.label.toLowerCase().replace(/\s+/g, '-')}`}
                className={`font-medium transition-all hover:text-primary ${
                  location === link.href
                    ? "text-primary text-shadow-neon-blue"
                    : "text-muted-foreground"
                }`}
              >
                {link.label}
              </Link>
            ))}

            {isAuthenticated ? (
              <div className="flex items-center gap-4 ml-4">
                <span className="font-semibold text-white flex items-center gap-2" data-testid="text-username">
                  <User className="w-4 h-4 text-primary" />
                  {user?.username}
                </span>
                <button
                  onClick={logout}
                  data-testid="button-logout"
                  className="px-4 py-2 rounded-full border border-destructive/30 text-destructive hover:bg-destructive/10 transition-all duration-300 flex items-center gap-2 font-semibold text-sm"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-3 ml-4">
                <Link
                  href="/login"
                  data-testid="link-login"
                  className="px-4 py-2 rounded-full border border-primary/30 text-primary hover:bg-primary/10 transition-all duration-300 flex items-center gap-2 font-semibold text-sm"
                >
                  <LogIn className="w-4 h-4" />
                  Login
                </Link>
                <Link
                  href="/daftar"
                  data-testid="link-register"
                  className="px-4 py-2 rounded-full bg-primary text-black hover:bg-white hover:shadow-[0_0_15px_rgba(0,255,255,0.4)] transition-all duration-300 flex items-center gap-2 font-semibold text-sm"
                >
                  <UserPlus className="w-4 h-4" />
                  Daftar
                </Link>
              </div>
            )}

            <Link
              href="/admin/login"
              data-testid="link-admin"
              className="ml-2 px-3 py-2 text-muted-foreground hover:text-white transition-all duration-300 flex items-center gap-1 font-semibold text-xs"
              title="Admin"
            >
              <User className="w-3 h-3" />
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-muted-foreground hover:text-primary transition-colors"
            onClick={() => setIsOpen(!isOpen)}
            data-testid="button-mobile-menu"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="md:hidden bg-card border-b border-primary/20 shadow-2xl absolute w-full">
          <div className="flex flex-col px-4 py-6 gap-4">
            {links.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setIsOpen(false)}
                className={`px-4 py-3 rounded-lg font-medium transition-all ${
                  location === link.href
                    ? "bg-primary/10 text-primary border border-primary/20"
                    : "text-muted-foreground hover:bg-muted hover:text-white"
                }`}
              >
                {link.label}
              </Link>
            ))}

            <div className="h-px bg-white/10 my-2"></div>

            {isAuthenticated ? (
              <>
                <div className="px-4 py-2 font-bold text-white flex items-center gap-2">
                  <User className="w-4 h-4 text-primary" />
                  {user?.username}
                </div>
                <button
                  onClick={() => { logout(); setIsOpen(false); }}
                  className="px-4 py-3 rounded-lg border border-destructive/30 text-destructive font-bold flex items-center gap-2 hover:bg-destructive/10 text-left"
                >
                  <LogOut className="w-4 h-4" />
                  Logout
                </button>
              </>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <Link
                  href="/login"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-3 rounded-lg border border-primary/30 text-primary font-bold flex items-center justify-center gap-2 hover:bg-primary/10"
                >
                  <LogIn className="w-4 h-4" />
                  Login
                </Link>
                <Link
                  href="/daftar"
                  onClick={() => setIsOpen(false)}
                  className="px-4 py-3 rounded-lg bg-primary text-black font-bold flex items-center justify-center gap-2 hover:bg-white"
                >
                  <UserPlus className="w-4 h-4" />
                  Daftar
                </Link>
              </div>
            )}

            <div className="h-px bg-white/10 my-2"></div>

            <Link
              href="/admin/login"
              onClick={() => setIsOpen(false)}
              className="px-4 py-3 rounded-lg text-muted-foreground font-bold flex items-center gap-2 hover:bg-white/5"
            >
              <User className="w-4 h-4" />
              Admin Dashboard
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
