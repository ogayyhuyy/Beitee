import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage, formatAccount } from "./storage";
import bcrypt from "bcryptjs";
import multer from "multer";
import path from "path";
import fs from "fs";
import { z } from "zod";

declare module "express-session" {
  interface SessionData {
    userId?: number;
    userUsername?: string;
    adminAuthenticated?: boolean;
    adminUsername?: string;
  }
}

const ADMIN_USERNAME = "admin";
const ADMIN_PASSWORD = "hubble123";

const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  if (req.session?.adminAuthenticated) return next();
  res.status(401).json({ error: "Unauthorized" });
};

const uploadsDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadsDir,
    filename: (_req, file, cb) => {
      cb(null, `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`);
    },
  }),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    if (file.mimetype.startsWith("image/")) cb(null, true);
    else cb(new Error("Only images allowed"));
  },
});

export async function registerRoutes(httpServer: Server, app: Express): Promise<Server> {
  // Serve uploads
  app.use("/api/uploads", (req, res, next) => {
    const filePath = path.join(uploadsDir, path.basename(req.path));
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      next();
    }
  });

  // ============ PUBLIC ACCOUNTS ============
  app.get("/api/accounts", async (req, res) => {
    try {
      const game = typeof req.query.game === "string" ? req.query.game : undefined;
      const status = typeof req.query.status === "string" ? req.query.status : undefined;
      const accounts = await storage.getAccounts({ game, status });
      res.json({ accounts: accounts.map(formatAccount) });
    } catch {
      res.status(500).json({ error: "Gagal mengambil daftar akun." });
    }
  });

  app.get("/api/accounts/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ error: "ID tidak valid." });
      const account = await storage.getAccountById(id);
      if (!account) return res.status(404).json({ error: "Akun tidak ditemukan." });
      res.json({ account: formatAccount(account) });
    } catch {
      res.status(500).json({ error: "Gagal mengambil detail akun." });
    }
  });

  // ============ AUTH ============
  app.post("/api/auth/register", async (req, res) => {
    try {
      const schema = z.object({
        username: z.string().min(3).max(30),
        email: z.string().email(),
        whatsapp: z.string().min(10),
        password: z.string().min(6),
        confirmPassword: z.string(),
      });
      const body = schema.parse(req.body);

      if (body.password !== body.confirmPassword) {
        return res.status(400).json({ error: "Password dan konfirmasi password tidak sama." });
      }

      const existingUsername = await storage.getUserByUsername(body.username);
      if (existingUsername) return res.status(409).json({ error: "Username sudah digunakan." });

      const existingEmail = await storage.getUserByEmail(body.email);
      if (existingEmail) return res.status(409).json({ error: "Email sudah digunakan." });

      const passwordHash = await bcrypt.hash(body.password, 10);
      await storage.createUser({
        username: body.username,
        email: body.email,
        whatsapp: body.whatsapp,
        passwordHash,
      });

      res.status(201).json({ message: "Akun berhasil dibuat, silakan login." });
    } catch (e) {
      res.status(400).json({ error: "Pendaftaran gagal, cek data Anda." });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const schema = z.object({
        usernameOrEmail: z.string(),
        password: z.string(),
      });
      const body = schema.parse(req.body);
      const user = await storage.getUserByUsernameOrEmail(body.usernameOrEmail);

      if (!user) return res.status(401).json({ error: "Username/email atau password salah." });

      const valid = await bcrypt.compare(body.password, user.passwordHash);
      if (!valid) return res.status(401).json({ error: "Username/email atau password salah." });

      req.session.userId = user.id;
      req.session.userUsername = user.username;

      res.json({
        success: true,
        message: "Login berhasil.",
        user: { id: user.id, username: user.username, email: user.email, whatsapp: user.whatsapp },
      });
    } catch {
      res.status(400).json({ error: "Login gagal." });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.userId = undefined;
    req.session.userUsername = undefined;
    res.json({ message: "Berhasil logout." });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) return res.json({ authenticated: false });
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      req.session.userId = undefined;
      return res.json({ authenticated: false });
    }
    res.json({
      authenticated: true,
      user: { id: user.id, username: user.username, email: user.email, whatsapp: user.whatsapp },
    });
  });

  // ============ ADMIN AUTH ============
  app.post("/api/admin/login", (req, res) => {
    const { username, password } = req.body;
    if (username === ADMIN_USERNAME && password === ADMIN_PASSWORD) {
      req.session.adminAuthenticated = true;
      req.session.adminUsername = username;
      res.json({ success: true, message: "Login berhasil." });
    } else {
      res.status(401).json({ error: "Username atau password salah." });
    }
  });

  app.post("/api/admin/logout", (req, res) => {
    req.session.adminAuthenticated = false;
    req.session.adminUsername = undefined;
    res.json({ message: "Logout berhasil." });
  });

  app.get("/api/admin/me", (req, res) => {
    if (req.session?.adminAuthenticated) {
      res.json({ authenticated: true, username: req.session.adminUsername });
    } else {
      res.json({ authenticated: false });
    }
  });

  // ============ ADMIN ACCOUNTS ============
  app.get("/api/admin/accounts", requireAdmin, async (req, res) => {
    try {
      const accounts = await storage.getAccounts();
      res.json({ accounts: accounts.map(formatAccount) });
    } catch {
      res.status(500).json({ error: "Gagal mengambil daftar akun." });
    }
  });

  app.post("/api/admin/accounts", requireAdmin, async (req, res) => {
    try {
      const schema = z.object({
        game: z.enum(["Mobile Legends", "Free Fire", "The Spike"]),
        rank: z.string().min(1),
        price: z.number().positive(),
        loginMethod: z.enum(["Moonton", "Google", "Facebook", "VK", "Guest"]),
        description: z.string(),
        imageUrls: z.array(z.string()).optional().default([]),
        status: z.enum(["TERSEDIA", "SOLD"]).default("TERSEDIA"),
      });
      const body = schema.parse(req.body);
      const unitCode = await storage.getNextUnitCode();
      const account = await storage.createAccount({ ...body, unitCode });
      res.status(201).json({ account: formatAccount(account) });
    } catch (e) {
      res.status(400).json({ error: "Gagal membuat akun. Cek data Anda." });
    }
  });

  app.patch("/api/admin/accounts/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const schema = z.object({
        game: z.enum(["Mobile Legends", "Free Fire", "The Spike"]).optional(),
        rank: z.string().optional(),
        price: z.number().optional(),
        loginMethod: z.enum(["Moonton", "Google", "Facebook", "VK", "Guest"]).optional(),
        description: z.string().optional(),
        imageUrls: z.array(z.string()).optional(),
        status: z.enum(["TERSEDIA", "SOLD"]).optional(),
      });
      const body = schema.parse(req.body);
      const account = await storage.updateAccount(id, body);
      if (!account) return res.status(404).json({ error: "Akun tidak ditemukan." });
      res.json({ account: formatAccount(account) });
    } catch {
      res.status(400).json({ error: "Gagal mengupdate akun." });
    }
  });

  app.patch("/api/admin/accounts/:id/status", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status } = z.object({ status: z.enum(["TERSEDIA", "SOLD"]) }).parse(req.body);
      const account = await storage.updateAccount(id, { status });
      if (!account) return res.status(404).json({ error: "Akun tidak ditemukan." });
      res.json({ account: formatAccount(account) });
    } catch {
      res.status(400).json({ error: "Gagal mengupdate status akun." });
    }
  });

  app.delete("/api/admin/accounts/:id", requireAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteAccount(id);
      res.json({ message: "Akun berhasil dihapus." });
    } catch {
      res.status(500).json({ error: "Gagal menghapus akun." });
    }
  });

  // ============ IMAGE UPLOAD ============
  app.post("/api/admin/upload", requireAdmin, upload.single("image"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "No file uploaded" });
    const url = `/api/uploads/${req.file.filename}`;
    res.json({ url });
  });

  // ============ TESTIMONIALS (public) ============
  app.get("/api/testimonials", async (req, res) => {
    try {
      const testimonialList = await storage.getTestimonials();
      res.json({ testimonials: testimonialList });
    } catch {
      res.status(500).json({ error: "Gagal mengambil testimoni." });
    }
  });

  return httpServer;
}
