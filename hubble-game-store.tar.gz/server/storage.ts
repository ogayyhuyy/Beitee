import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import { eq, asc, desc, or } from "drizzle-orm";
import { users, gameAccounts, testimonials, type User, type InsertUser, type GameAccount, type InsertGameAccount, type Testimonial, type InsertTestimonial } from "@shared/schema";

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool);

function parseImageUrls(raw: string): string[] {
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function formatAccount(a: GameAccount) {
  return {
    ...a,
    price: Number(a.price),
    imageUrls: parseImageUrls(a.imageUrls),
    createdAt: a.createdAt.toISOString(),
  };
}

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsernameOrEmail(usernameOrEmail: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Game Accounts
  getAccounts(filters?: { game?: string; status?: string }): Promise<GameAccount[]>;
  getAccountById(id: number): Promise<GameAccount | undefined>;
  createAccount(data: Omit<InsertGameAccount, 'unitCode'> & { unitCode: string }): Promise<GameAccount>;
  updateAccount(id: number, data: Partial<InsertGameAccount>): Promise<GameAccount | undefined>;
  deleteAccount(id: number): Promise<void>;
  getNextUnitCode(): Promise<string>;

  // Testimonials
  getTestimonials(): Promise<Testimonial[]>;
  createTestimonial(data: InsertTestimonial): Promise<Testimonial>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    return user;
  }

  async getUserByUsernameOrEmail(usernameOrEmail: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(
      or(eq(users.username, usernameOrEmail), eq(users.email, usernameOrEmail))
    ).limit(1);
    return user;
  }

  async createUser(data: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(data).returning();
    return user;
  }

  async getAccounts(filters?: { game?: string; status?: string }): Promise<GameAccount[]> {
    let accounts = await db.select().from(gameAccounts).orderBy(asc(gameAccounts.id));
    if (filters?.game) {
      accounts = accounts.filter(a => a.game === filters.game);
    }
    if (filters?.status) {
      accounts = accounts.filter(a => a.status === filters.status);
    }
    return accounts;
  }

  async getAccountById(id: number): Promise<GameAccount | undefined> {
    const [account] = await db.select().from(gameAccounts).where(eq(gameAccounts.id, id)).limit(1);
    return account;
  }

  async getNextUnitCode(): Promise<string> {
    const accounts = await db
      .select({ unitCode: gameAccounts.unitCode })
      .from(gameAccounts)
      .orderBy(desc(gameAccounts.id));

    const existingNums = accounts
      .map(a => {
        const match = a.unitCode.match(/^HS(\d+)$/);
        return match ? parseInt(match[1], 10) : 0;
      })
      .filter(n => n > 0);

    const maxNum = existingNums.length > 0 ? Math.max(...existingNums) : 0;
    return `HS${String(maxNum + 1).padStart(3, "0")}`;
  }

  async createAccount(data: Omit<InsertGameAccount, 'unitCode'> & { unitCode: string }): Promise<GameAccount> {
    const imageUrls = Array.isArray(data.imageUrls) ? data.imageUrls : [];
    const [account] = await db.insert(gameAccounts).values({
      ...data,
      imageUrls: JSON.stringify(imageUrls),
    }).returning();
    return account;
  }

  async updateAccount(id: number, data: Partial<InsertGameAccount>): Promise<GameAccount | undefined> {
    const updateData: Partial<typeof gameAccounts.$inferInsert> = {};
    if (data.game !== undefined) updateData.game = data.game;
    if (data.rank !== undefined) updateData.rank = data.rank;
    if (data.price !== undefined) updateData.price = String(data.price);
    if (data.loginMethod !== undefined) updateData.loginMethod = data.loginMethod;
    if (data.description !== undefined) updateData.description = data.description;
    if (data.status !== undefined) updateData.status = data.status;
    if (data.imageUrls !== undefined) {
      updateData.imageUrls = JSON.stringify(Array.isArray(data.imageUrls) ? data.imageUrls : []);
    }

    const [account] = await db.update(gameAccounts).set(updateData).where(eq(gameAccounts.id, id)).returning();
    return account;
  }

  async deleteAccount(id: number): Promise<void> {
    await db.delete(gameAccounts).where(eq(gameAccounts.id, id));
  }

  async getTestimonials(): Promise<Testimonial[]> {
    return db.select().from(testimonials).orderBy(desc(testimonials.createdAt));
  }

  async createTestimonial(data: InsertTestimonial): Promise<Testimonial> {
    const [testimonial] = await db.insert(testimonials).values(data).returning();
    return testimonial;
  }
}

export const storage = new DatabaseStorage();
